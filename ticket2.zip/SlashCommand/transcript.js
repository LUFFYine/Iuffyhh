const discordTranscripts = require('discord-html-transcripts');
const { Database } = require('st.db')
const db = new Database('DataBots/Tickets')
const { EmbedBuilder } = require('discord.js')
module.exports =  {
    name: 'transcript',
    type: 1,
    description: 'Create a transcript of the current ticket',
    options: [{ name: 'channel', type: 7, description: 'Select the Channel', required: true }],
    
    /**
     * 
     * @param { import('discord.js').Client } Client 
     * @param { import('discord.js').ChatInputCommandInteraction } Interaction 
     */

    run: async(Client, Interaction) => {
        const dd = new Database('DataBots/Tickets')
        const Support = dd.get(`TICKET-PANEL_${Interaction.channel.id}`)?.Support
       if (!Interaction.member.permissions.has('Administrator')) return Interaction.reply({ content: `Only the Administrator Permission can use this Command`})


        const Channel = Interaction.options.getChannel('channel') || Interaction.channel;
        if(!db.get(`TICKET-PANEL_${Channel.id}`)) return Interaction.reply({ content: `> This channel isn't a ticket`, ephemeral: true })
        const attachment = await discordTranscripts.createTranscript(Channel);
        const Logs = db.get(`LogsRoom_${Interaction.guild.id}`)
        const Log = Interaction.guild.channels.cache.get(Logs)
        const Ticket = db.get(`TICKET-PANEL_${Channel.id}`)
        const Embed = new EmbedBuilder()
        .setAuthor({ name: Interaction.user.tag, iconURL: Interaction.user.displayAvatarURL()})
        .setTitle('Transcripted Ticket')
        .setFields(
            { name: `Name Ticket`, value: `${Channel.name}`},
            { name: `Owner Ticket`, value: `${Ticket.author}`},
            { name: `Transcript BY `, value: `${Interaction.user}`},

        )
        .setFooter({ text: Interaction.user.tag, iconURL: Interaction.user.displayAvatarURL()})
        Log?.send({ embeds: [Embed]})
        Channel.send({ files: [attachment] })
        Log?.send({ files: [attachment] })
    }
}