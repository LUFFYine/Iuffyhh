const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js")

module.exports = {
    name: 'come',
    description: 'request the user',
    options: [
        {
            name: 'user',
            type: 6,
            description: 'select the user',
            required: true
        }
    ],


 /**
 * @param { import ('discord.js').Client } Client 
 * @param { import ('discord.js').Interaction } Interaction 
 */


    run: async( Client, Interaction ) => {
    const user = Interaction.options.getMember('user')
    if (!Interaction.member.permissions.has('Administrator')) return;
    const Embed = new EmbedBuilder()
    .setAuthor({ name: `استدعاء من ${Interaction.guild.name}`, iconURL: Interaction.guild.iconURL()})
    .setFooter({ text: Interaction.guild.name, iconURL: Interaction.guild.iconURL()})
    .setThumbnail(Interaction.guild.iconURL()).setColor('Green').setTitle('Please Come')
    .setDescription(`**مرحبا بك ${user.displayName} 👋\n\nتم استدعائك في سيرفر ${Interaction.guild.name} 💎**`)
    const Row = new ActionRowBuilder()
    .addComponents(new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(`https://discord.com/channels/${Interaction.guild.id}/${Interaction.channel.id}`).setLabel('اضغط للذهاب'))
    user.send({ embeds: [Embed], components: [Row]})
    Interaction.reply({ content: `**🟢 ${user} has been successfully summoned to the event. Please wait while he arrives at the venue.**`})
   }
}