const { EmbedBuilder } = require('discord.js');
const { Database } = require('st.db')
const db = new Database('DataBots/Tickets')

module.exports =  {
    name: 'delete',
    type: 1,
    description: 'Delete the current ticket channel',
    
    /**
     * 
     * @param { import('discord.js').Client } Client 
     * @param { import('discord.js').ChatInputCommandInteraction } Interaction 
     */

    run: async(Client, Interaction) => {
        const dd = new Database('DataBots/Tickets')
        const Support = dd.get(`TICKET-PANEL_${Interaction.channel.id}`)?.Support
        if (!Interaction.member.roles.cache.has(Support)) return Interaction.reply({ content: `:x: Only Support`, ephemeral: true})

        if(!db.has(`TICKET-PANEL_${Interaction.channel.id}`)) return Interaction.reply({ content: `> This channel isn't a ticket`, ephemeral: true })
        const Embed = new EmbedBuilder() .setColor('Red') .setDescription(`Ticket will be deleted in a few seconds`)
        db.delete(`TICKET-PANEL_${Interaction.channel.id}`)
        Interaction.reply({ embeds: [Embed] })
        setTimeout(() => {
            Interaction.channel.delete()
        }, 4500)
        const Logs = db.get(`LogsRoom_${Interaction.guild.id}`)
        const Log = Interaction.guild.channels.cache.get(Logs)
        const Ticket = db.get(`TICKET-PANEL_${Interaction.channel.id}`)
        const Embedd = new EmbedBuilder()
        .setAuthor({ name: Interaction.user.tag, iconURL: Interaction.user.displayAvatarURL()})
        .setTitle('Delete Ticket')
        .setFields(
            { name: `Name Ticket`, value: `${Interaction.channel.name}`},
            { name: `Owner Ticket`, value: `${Ticket.author}`},
            { name: `Delete BY Ticket`, value: `${Interaction.user}`},

        )
        .setFooter({ text: Interaction.user.tag, iconURL: Interaction.user.displayAvatarURL()})
        Log?.send({ embeds: [Embedd]})

    }
}