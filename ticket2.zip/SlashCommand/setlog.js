const { Database } = require("st.db")

const db = new Database('DataBots/Tickets')
module.exports = {
    name: 'setlog',
    description: 'Set Log Channel',
    options: [
        {
            name: 'channel',
            description: 'Channel',
            type: 7,
            required: true,
        },
    ],
    run: async (client, interaction) => {
    if (interaction.member.permissions.has('Administrator')) {
        const channel = interaction.options.getChannel('channel')
        if (channel.type!== 'GUILD_TEXT') return interaction.reply({ content: 'Please provide a valid text channel', ephemeral: true })
        await db.set(`LogsRoom_${interaction.guild.id}`, channel.id)
        interaction.reply({ content: `Log Channel has been set to ${channel}`, ephemeral: true })
    }
    }
}