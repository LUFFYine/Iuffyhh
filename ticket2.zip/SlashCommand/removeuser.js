const { Database } = require('st.db')
const db = new Database('DataBots/Tickets')

module.exports =  {
    name: 'removeuser',
    type: 1,
    description: 'Remove User the current ticket channel',
    options: [{ name: 'user', type: 6, description: 'Select the User', required: true }],
    
    /**
     * 
     * @param { import('discord.js').Client } Client 
     * @param { import('discord.js').ChatInputCommandInteraction } Interaction 
     */

    run: async(Client, Interaction) => {
        const dd = new Database('DataBots/Tickets')
        const Support = dd.get(`TICKET-PANEL_${Interaction.channel.id}`)?.Support
        if (!Interaction.member.roles.cache.has(Support)) return Interaction.reply({ content: `:x: Only Support`, ephemeral: true})

        const Member = Interaction.options.getMember('user');
        if(!db.has(`TICKET-PANEL_${Interaction.channel.id}`)) return Interaction.reply({ content: `> This channel isn't a ticket`, ephemeral: true })
        await Interaction.channel.permissionOverwrites.edit(Member.user.id, {
            ViewChannel: false,
            SendMessages: false
        })
        Interaction.reply({ embeds: [{ description: `${Member} removed from ticket ${Interaction.channel}` }] })
    }
}