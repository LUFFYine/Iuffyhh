const { Database } = require('st.db')
const db = new Database('DataBots/Tickets')
const { EmbedBuilder, ActionRowBuilder, ButtonStyle, ButtonBuilder } = require("discord.js")

module.exports =  {
    name: 'close',
    type: 1,
    description: 'Close the ticket.',
    
    run: async(Client, Interaction) => {
        const dd = new Database('DataBots/Tickets')
        const Support = dd.get(`TICKET-PANEL_${Interaction.channel.id}`)?.Support
        if (!Interaction.member.roles.cache.has(Support)) return Interaction.reply({ content: `:x: Only Support`, ephemeral: true})

        db.add(`closed`, 1)
        const id = db.get('closed')
        const Ticket = db.get(`TICKET-PANEL_${Interaction.channel.id}`)
        Interaction.channel.permissionOverwrites.edit( Ticket.author, { ViewChannel: false })
        const Embed = new EmbedBuilder()
        .setDescription(`**تم اغلاق التذكره**`)
        const Roww = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder().setCustomId('delete').setLabel('حذف').setEmoji('🎯').setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId('Open').setLabel('فتح').setEmoji('🔓').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('Tran').setLabel('حفظ التذكره').setEmoji('📃').setStyle(ButtonStyle.Secondary),
        )
        await Interaction.reply({ embeds: [Embed], components: [Roww]}).then(() => {
        Interaction.channel.setName(`🔓 closed-${id}`)
        const Logs = db.get(`LogsRoom_${Interaction.guild.id}`)
        const Log = Interaction.guild.channels.cache.get(Logs)
        const Ticket = db.get(`TICKET-PANEL_${Interaction.channel.id}`)
        const Embedd = new EmbedBuilder()
        .setAuthor({ name: Interaction.user.tag, iconURL: Interaction.user.displayAvatarURL()})
        .setTitle('Close Ticket')
        .setFields(
            { name: `Name Ticket`, value: `${Interaction.channel.name}`},
            { name: `Owner Ticket`, value: `${Ticket.author}`},
            { name: `Close BY Ticket`, value: `${Interaction.user}`},

        )
        .setFooter({ text: Interaction.user.tag, iconURL: Interaction.user.displayAvatarURL()})
        Log?.send({ embeds: [Embedd]})

        })
    }
}