const { Database } = require('st.db')
const db = new Database('DataBots/Tickets')

module.exports =  {
    name: 'rename',
    type: 1,
    description: 'Rename the current ticket channel',
    options: [{ name: 'name', type: 3, description: 'Enter the Name', required: false }],
    
    /**
     * 
     * @param { import('discord.js').Client } Client 
     * @param { import('discord.js').ChatInputCommandInteraction } Interaction 
     */

    run: async(Client, Interaction) => {
        const dd = new Database('DataBots/Tickets')
        const Support = dd.get(`TICKET-PANEL_${Interaction.channel.id}`)?.Support
        if (!Interaction.member.roles.cache.has(Support)) return Interaction.reply({ content: `:x: Only Support`, ephemeral: true})

        const Name = Interaction.options.getString('name');
        const Ticket = db.get(`TICKET-PANEL_${Interaction.channel.id}`)
        if(!Ticket) return Interaction.reply({ content: `> This channel isn't a ticket`, ephemeral: true })
        if(!Name) {
            Interaction.channel.setName(`ticket-${Ticket.ticket_id}`)
            Interaction.reply({ content: `Forced rename has been removed`, ephemeral: true })
        } else {
            Interaction.channel.setName(Name);
            Interaction.reply({ content: `Channel renamed`, ephemeral: true })
        }
    }
}