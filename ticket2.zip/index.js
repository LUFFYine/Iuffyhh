const { Client, GatewayIntentBits, Collection } = require('discord.js')
// Client Intents
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildPresences,
    ]
})
// Client Ready
client.on('ready', () => {
    client.user.setStatus('idle')
    client.user.setActivity('im bot ticket')
    console.log('Client Is Ready', client.user.username)
})

// Handler
const fs = require('fs')
client.slashCommands = new Collection()
client.Çʍɗ = new Collection()
fs.readdirSync('./Handler/').forEach((Handler) => require(`./Handler/${Handler}`)(client))
module.exports = client;
client.config = require('./config.json')


// Client Login
client.login('')