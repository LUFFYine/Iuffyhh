const { EmbedBuilder, ButtonStyle, ActionRowBuilder, ButtonBuilder  } = require("discord.js")
const { Database } = require('st.db')
const dd = new Database('DataBots/Tickets')

module.exports = async( Client, Interaction ) => {
   
   
    if (Interaction.customId === 'claim') {
        const Support = dd.get(`TICKET-PANEL_${Interaction.channel.id}`).Support
        if (!Interaction.member.roles.cache.has(Support)) return Interaction.reply({ content: `:x: Only Support`, ephemeral: true})
        dd.add(`Points_${Interaction.user.id}`, 1)

        dd.set(`Claimed_${Interaction.channel.id}`, Interaction.user.id)
        const Row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder() .setStyle(ButtonStyle.Secondary) .setEmoji('🔒') .setCustomId(`Panel`),
            new ButtonBuilder().setCustomId('55555555555').setStyle(ButtonStyle.Success).setDisabled().setEmoji('✅').setLabel(`by ${Interaction.user.username}`),
            new ButtonBuilder().setCustomId('unclaim').setStyle(ButtonStyle.Primary).setLabel('UnClaimed'))
        Interaction.channel.permissionOverwrites.edit(Support, { SendMessages: false})
        Interaction.channel.permissionOverwrites.edit(Interaction.user.id, { SendMessages: true})
        await Interaction.deferUpdate()
        await Interaction.editReply({ components: [Row]})
        Interaction.channel.setName(`By ${Interaction.user.username}`)
    } else  if (Interaction.customId === 'unclaim') {

       if (dd.get(`Claimed_${Interaction.channel.id}`) == Interaction.user.id) {
        const dd = new Database('DataBots/Tickets')
        const Support = dd.get(`TICKET-PANEL_${Interaction.channel.id}`)?.Support
        const ticket_id = dd.get(`TICKET-PANEL_${Interaction.channel.id}`)?.author
        const id = Interaction.guild.members.cache.get(ticket_id)
        if (!Interaction.member.roles.cache.has(Support)) return Interaction.reply({ content: `:x: Only Support`, ephemeral: true})
        Interaction.channel.permissionOverwrites.edit(Support, { SendMessages: true})
        Interaction.channel.permissionOverwrites.edit(Interaction.user.id, { SendMessages: false})
        const Row = new ActionRowBuilder()
        .addComponents(
        new ButtonBuilder() .setStyle(ButtonStyle.Secondary) .setEmoji('🔒') .setCustomId(`close`),
        new ButtonBuilder() .setStyle(ButtonStyle.Secondary) .setEmoji('📍') .setLabel('Claim') .setCustomId(`claim`))
        dd.subtract(`Points_${Interaction.user.id}`, 1)
        await Interaction.deferUpdate()
        await Interaction.editReply({ components: [Row]})
        await Interaction.channel.setName(`re-claim`)
    } else {
        return Interaction.reply({ content: `**التيكت ليست لك**`, ephemeral: true})
    }}
}